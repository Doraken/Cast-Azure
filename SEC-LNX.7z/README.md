SEC-LNX
===============

automated linux securing script based on CAST.

This script may be used to chek or to appkys all security rules that have been 
activated in the sonfiguration file . 

This script will générate a complience report. 

And all non spécific part issued from CAST are only property of the owner ARNAUD CRAMPET


Arnaud Crampet / Doraken


Mail : arnaud@crampet.net 